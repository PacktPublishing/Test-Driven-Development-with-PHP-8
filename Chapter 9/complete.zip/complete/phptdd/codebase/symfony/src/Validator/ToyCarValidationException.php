<?php

namespace App\Validator;

class ToyCarValidationException extends \Exception
{

}