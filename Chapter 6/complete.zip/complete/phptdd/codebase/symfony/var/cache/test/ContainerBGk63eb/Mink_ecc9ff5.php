<?php

namespace ContainerBGk63eb;
include_once \dirname(__DIR__, 4).'/vendor/behat/mink/src/Mink.php';

class Mink_ecc9ff5 extends \Behat\Mink\Mink implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Behat\Mink\Mink|null wrapped object, if the proxy is initialized
     */
    private $valueHolder94997 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer2b93e = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiescde15 = [
        
    ];

    public function registerSession($name, \Behat\Mink\Session $session)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'registerSession', array('name' => $name, 'session' => $session), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->registerSession($name, $session);
    }

    public function hasSession($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'hasSession', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->hasSession($name);
    }

    public function setDefaultSessionName($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'setDefaultSessionName', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->setDefaultSessionName($name);
    }

    public function getDefaultSessionName()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'getDefaultSessionName', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->getDefaultSessionName();
    }

    public function getSession($name = null)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'getSession', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->getSession($name);
    }

    public function isSessionStarted($name = null)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'isSessionStarted', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->isSessionStarted($name);
    }

    public function assertSession($session = null)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'assertSession', array('session' => $session), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->assertSession($session);
    }

    public function resetSessions()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'resetSessions', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->resetSessions();
    }

    public function restartSessions()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'restartSessions', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->restartSessions();
    }

    public function stopSessions()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'stopSessions', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->stopSessions();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Behat\Mink\Mink $instance) {
            unset($instance->defaultSessionName, $instance->sessions);
        }, $instance, 'Behat\\Mink\\Mink')->__invoke($instance);

        $instance->initializer2b93e = $initializer;

        return $instance;
    }

    public function __construct(array $sessions = [])
    {
        static $reflection;

        if (! $this->valueHolder94997) {
            $reflection = $reflection ?? new \ReflectionClass('Behat\\Mink\\Mink');
            $this->valueHolder94997 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Behat\Mink\Mink $instance) {
            unset($instance->defaultSessionName, $instance->sessions);
        }, $this, 'Behat\\Mink\\Mink')->__invoke($this);

        }

        $this->valueHolder94997->__construct($sessions);
    }

    public function & __get($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__get', ['name' => $name], $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        if (isset(self::$publicPropertiescde15[$name])) {
            return $this->valueHolder94997->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Behat\\Mink\\Mink');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('Behat\\Mink\\Mink');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__isset', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('Behat\\Mink\\Mink');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__unset', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('Behat\\Mink\\Mink');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__clone', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $this->valueHolder94997 = clone $this->valueHolder94997;
    }

    public function __sleep()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__sleep', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return array('valueHolder94997');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Behat\Mink\Mink $instance) {
            unset($instance->defaultSessionName, $instance->sessions);
        }, $this, 'Behat\\Mink\\Mink')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer2b93e = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer2b93e;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'initializeProxy', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder94997;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder94997;
    }

    public function __destruct()
    {
        $this->initializer2b93e || $this->valueHolder94997->__destruct();
    }
}

if (!\class_exists('Mink_ecc9ff5', false)) {
    \class_alias(__NAMESPACE__.'\\Mink_ecc9ff5', 'Mink_ecc9ff5', false);
}
