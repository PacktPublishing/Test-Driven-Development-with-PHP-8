<?php

namespace ContainerXlczrZc;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderd8ec6 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerbc2c7 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties06398 = [
        
    ];

    public function getConnection()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getConnection', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getMetadataFactory', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getExpressionBuilder', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'beginTransaction', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getCache', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getCache();
    }

    public function transactional($func)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'transactional', array('func' => $func), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'wrapInTransaction', array('func' => $func), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'commit', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->commit();
    }

    public function rollback()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'rollback', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getClassMetadata', array('className' => $className), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'createQuery', array('dql' => $dql), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'createNamedQuery', array('name' => $name), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'createQueryBuilder', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'flush', array('entity' => $entity), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'clear', array('entityName' => $entityName), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->clear($entityName);
    }

    public function close()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'close', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->close();
    }

    public function persist($entity)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'persist', array('entity' => $entity), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'remove', array('entity' => $entity), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'refresh', array('entity' => $entity), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'detach', array('entity' => $entity), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'merge', array('entity' => $entity), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getRepository', array('entityName' => $entityName), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'contains', array('entity' => $entity), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getEventManager', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getConfiguration', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'isOpen', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getUnitOfWork', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getProxyFactory', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'initializeObject', array('obj' => $obj), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'getFilters', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'isFiltersStateClean', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'hasFilters', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return $this->valueHolderd8ec6->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerbc2c7 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderd8ec6) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderd8ec6 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderd8ec6->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, '__get', ['name' => $name], $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        if (isset(self::$publicProperties06398[$name])) {
            return $this->valueHolderd8ec6->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8ec6;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderd8ec6;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8ec6;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderd8ec6;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, '__isset', array('name' => $name), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8ec6;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderd8ec6;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, '__unset', array('name' => $name), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8ec6;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderd8ec6;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, '__clone', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        $this->valueHolderd8ec6 = clone $this->valueHolderd8ec6;
    }

    public function __sleep()
    {
        $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, '__sleep', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;

        return array('valueHolderd8ec6');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerbc2c7 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerbc2c7;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerbc2c7 && ($this->initializerbc2c7->__invoke($valueHolderd8ec6, $this, 'initializeProxy', array(), $this->initializerbc2c7) || 1) && $this->valueHolderd8ec6 = $valueHolderd8ec6;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderd8ec6;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderd8ec6;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
