<?php

namespace App\Model;

interface ModelInterface
{

}