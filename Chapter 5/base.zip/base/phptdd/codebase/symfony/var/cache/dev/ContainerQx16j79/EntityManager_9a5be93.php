<?php

namespace ContainerQx16j79;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder7977a = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializeree793 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties0b122 = [
        
    ];

    public function getConnection()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getConnection', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getMetadataFactory', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getExpressionBuilder', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'beginTransaction', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->beginTransaction();
    }

    public function getCache()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getCache', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getCache();
    }

    public function transactional($func)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'transactional', array('func' => $func), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'wrapInTransaction', array('func' => $func), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'commit', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->commit();
    }

    public function rollback()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'rollback', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getClassMetadata', array('className' => $className), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'createQuery', array('dql' => $dql), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'createNamedQuery', array('name' => $name), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'createQueryBuilder', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'flush', array('entity' => $entity), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'clear', array('entityName' => $entityName), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->clear($entityName);
    }

    public function close()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'close', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->close();
    }

    public function persist($entity)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'persist', array('entity' => $entity), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'remove', array('entity' => $entity), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'refresh', array('entity' => $entity), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'detach', array('entity' => $entity), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'merge', array('entity' => $entity), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getRepository', array('entityName' => $entityName), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'contains', array('entity' => $entity), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getEventManager', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getConfiguration', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'isOpen', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getUnitOfWork', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getProxyFactory', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'initializeObject', array('obj' => $obj), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'getFilters', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'isFiltersStateClean', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'hasFilters', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return $this->valueHolder7977a->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializeree793 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config)
    {
        static $reflection;

        if (! $this->valueHolder7977a) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder7977a = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder7977a->__construct($conn, $config);
    }

    public function & __get($name)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, '__get', ['name' => $name], $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        if (isset(self::$publicProperties0b122[$name])) {
            return $this->valueHolder7977a->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7977a;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7977a;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, '__set', array('name' => $name, 'value' => $value), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7977a;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7977a;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, '__isset', array('name' => $name), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7977a;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder7977a;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, '__unset', array('name' => $name), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7977a;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder7977a;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, '__clone', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        $this->valueHolder7977a = clone $this->valueHolder7977a;
    }

    public function __sleep()
    {
        $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, '__sleep', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;

        return array('valueHolder7977a');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializeree793 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializeree793;
    }

    public function initializeProxy() : bool
    {
        return $this->initializeree793 && ($this->initializeree793->__invoke($valueHolder7977a, $this, 'initializeProxy', array(), $this->initializeree793) || 1) && $this->valueHolder7977a = $valueHolder7977a;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder7977a;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder7977a;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
