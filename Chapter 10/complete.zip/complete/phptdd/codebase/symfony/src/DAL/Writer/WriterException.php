<?php

namespace App\DAL\Writer;

class WriterException extends \Exception
{

}