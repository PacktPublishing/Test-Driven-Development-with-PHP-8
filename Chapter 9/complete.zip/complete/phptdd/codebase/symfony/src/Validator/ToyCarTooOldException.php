<?php

namespace App\Validator;

class ToyCarTooOldException extends ToyCarValidationException
{

}