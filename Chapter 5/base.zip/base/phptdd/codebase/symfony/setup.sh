#!/bin/bash
composer install -d /var/www/html/symfony/