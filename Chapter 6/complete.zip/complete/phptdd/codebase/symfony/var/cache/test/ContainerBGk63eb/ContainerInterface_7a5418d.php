<?php

namespace ContainerBGk63eb;
include_once \dirname(__DIR__, 4).'/vendor/symfony/dependency-injection/ContainerInterface.php';

class ContainerInterface_7a5418d implements \ProxyManager\Proxy\VirtualProxyInterface, \Symfony\Component\DependencyInjection\ContainerInterface
{
    /**
     * @var \Symfony\Component\DependencyInjection\ContainerInterface|null wrapped object, if the proxy is initialized
     */
    private $valueHolder94997 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer2b93e = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiescde15 = [
        
    ];

    public function set(string $id, ?object $service)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'set', array('id' => $id, 'service' => $service), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->set($id, $service);
    }

    public function get(string $id, int $invalidBehavior = 1) : ?object
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'get', array('id' => $id, 'invalidBehavior' => $invalidBehavior), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->get($id, $invalidBehavior);
    }

    public function has(string $id) : bool
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'has', array('id' => $id), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->has($id);
    }

    public function initialized(string $id) : bool
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'initialized', array('id' => $id), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->initialized($id);
    }

    public function getParameter(string $name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'getParameter', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->getParameter($name);
    }

    public function hasParameter(string $name) : bool
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'hasParameter', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->hasParameter($name);
    }

    public function setParameter(string $name, \UnitEnum|bool|int|float|string|array|null $value)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'setParameter', array('name' => $name, 'value' => $value), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->setParameter($name, $value);
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        $instance->initializer2b93e = $initializer;

        return $instance;
    }

    public function __construct()
    {
        static $reflection;

        if (! $this->valueHolder94997) {
            $reflection = $reflection ?? new \ReflectionClass('Symfony\\Component\\DependencyInjection\\ContainerInterface');
            $this->valueHolder94997 = $reflection->newInstanceWithoutConstructor();
        }
    }

    public function & __get($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__get', ['name' => $name], $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        if (isset(self::$publicPropertiescde15[$name])) {
            return $this->valueHolder94997->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Symfony\\Component\\DependencyInjection\\ContainerInterface');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('Symfony\\Component\\DependencyInjection\\ContainerInterface');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__isset', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('Symfony\\Component\\DependencyInjection\\ContainerInterface');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__unset', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('Symfony\\Component\\DependencyInjection\\ContainerInterface');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__clone', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $this->valueHolder94997 = clone $this->valueHolder94997;
    }

    public function __sleep()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__sleep', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return array('valueHolder94997');
    }

    public function __wakeup()
    {
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer2b93e = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer2b93e;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'initializeProxy', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder94997;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder94997;
    }
}

if (!\class_exists('ContainerInterface_7a5418d', false)) {
    \class_alias(__NAMESPACE__.'\\ContainerInterface_7a5418d', 'ContainerInterface_7a5418d', false);
}
