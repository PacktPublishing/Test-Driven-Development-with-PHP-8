<?php

namespace ContainerBGk63eb;
include_once \dirname(__DIR__, 4).'/vendor/friends-of-behat/symfony-extension/src/Mink/MinkParameters.php';

class MinkParameters_4b72c85 extends \FriendsOfBehat\SymfonyExtension\Mink\MinkParameters implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \FriendsOfBehat\SymfonyExtension\Mink\MinkParameters|null wrapped object, if the proxy is initialized
     */
    private $valueHolder94997 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer2b93e = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiescde15 = [
        
    ];

    #[\ReturnTypeWillChange]
    public function getIterator() : \Traversable
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'getIterator', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->getIterator();
    }

    #[\ReturnTypeWillChange]
    public function offsetExists($offset) : bool
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'offsetExists', array('offset' => $offset), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->offsetExists($offset);
    }

    #[\ReturnTypeWillChange]
    public function offsetGet($offset)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'offsetGet', array('offset' => $offset), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->offsetGet($offset);
    }

    #[\ReturnTypeWillChange]
    public function offsetSet($offset, $value) : void
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'offsetSet', array('offset' => $offset, 'value' => $value), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $this->valueHolder94997->offsetSet($offset, $value);
return;
    }

    #[\ReturnTypeWillChange]
    public function offsetUnset($offset) : void
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'offsetUnset', array('offset' => $offset), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $this->valueHolder94997->offsetUnset($offset);
return;
    }

    #[\ReturnTypeWillChange]
    public function count() : int
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'count', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return $this->valueHolder94997->count();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\FriendsOfBehat\SymfonyExtension\Mink\MinkParameters $instance) {
            unset($instance->minkParameters);
        }, $instance, 'FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters')->__invoke($instance);

        $instance->initializer2b93e = $initializer;

        return $instance;
    }

    public function __construct(array $minkParameters)
    {
        static $reflection;

        if (! $this->valueHolder94997) {
            $reflection = $reflection ?? new \ReflectionClass('FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters');
            $this->valueHolder94997 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\FriendsOfBehat\SymfonyExtension\Mink\MinkParameters $instance) {
            unset($instance->minkParameters);
        }, $this, 'FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters')->__invoke($this);

        }

        $this->valueHolder94997->__construct($minkParameters);
    }

    public function & __get($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__get', ['name' => $name], $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        if (isset(self::$publicPropertiescde15[$name])) {
            return $this->valueHolder94997->$name;
        }

        $realInstanceReflection = new \ReflectionClass('FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__isset', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__unset', array('name' => $name), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $realInstanceReflection = new \ReflectionClass('FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder94997;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder94997;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__clone', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        $this->valueHolder94997 = clone $this->valueHolder94997;
    }

    public function __sleep()
    {
        $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, '__sleep', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;

        return array('valueHolder94997');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\FriendsOfBehat\SymfonyExtension\Mink\MinkParameters $instance) {
            unset($instance->minkParameters);
        }, $this, 'FriendsOfBehat\\SymfonyExtension\\Mink\\MinkParameters')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer2b93e = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer2b93e;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer2b93e && ($this->initializer2b93e->__invoke($valueHolder94997, $this, 'initializeProxy', array(), $this->initializer2b93e) || 1) && $this->valueHolder94997 = $valueHolder94997;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder94997;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder94997;
    }
}

if (!\class_exists('MinkParameters_4b72c85', false)) {
    \class_alias(__NAMESPACE__.'\\MinkParameters_4b72c85', 'MinkParameters_4b72c85', false);
}
